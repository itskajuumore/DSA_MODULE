package Assiignment_1;

public class Stack_Example {

}
